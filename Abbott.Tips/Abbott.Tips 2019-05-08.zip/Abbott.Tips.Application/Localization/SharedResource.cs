﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abbott.Tips.Application.Localization
{
    public class SharedResource
    {
    }
}
