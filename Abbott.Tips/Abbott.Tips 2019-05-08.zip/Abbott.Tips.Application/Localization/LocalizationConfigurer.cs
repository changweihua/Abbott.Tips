﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abbott.Tips.Application.Localization
{
    public static class PricingSystemLocalizationConfigurer
    {
        //public static void Configure(ILocalizationConfiguration localizationConfiguration)
        //{
        //    localizationConfiguration.Sources.Add(
        //        new DictionaryBasedLocalizationSource(PricingSystemConsts.LocalizationSourceName,
        //            new XmlEmbeddedFileLocalizationDictionaryProvider(
        //                typeof(PricingSystemLocalizationConfigurer).GetAssembly(),
        //                "Abbott.PricingSystem.Localization.SourceFiles"
        //            )
        //        )
        //    );
        //}
    }
}
