﻿using Abbott.Tips.Model.Query;
using System;
using System.Collections.Generic;
using System.Text;

namespace Abbott.Tips.Application.Configurations.Dtos
{
    public class ConfigurationPagerParameterQueryModel : PagerParameterQueryModel
    {
    }
}
