﻿using Abbott.Tips.Application.BCL;
using System;
using System.Collections.Generic;
using System.Text;

namespace Abbott.Tips.Application.Configurations.Dtos
{
    public class AConfigurationAttribute : JilSerializationFilterAttribute
    {
    }

    public class BConfigurationAttribute : JilSerializationFilterAttribute
    {
    }
}
