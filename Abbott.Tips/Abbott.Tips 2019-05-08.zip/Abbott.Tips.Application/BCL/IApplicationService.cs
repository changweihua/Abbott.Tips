﻿using Abbott.Tips.Framework.Dependency;
using System;
using System.Collections.Generic;
using System.Text;

namespace Abbott.Tips.Application.BCL
{
    public interface IApplicationService : ITransientDependency
    {
    }
}
