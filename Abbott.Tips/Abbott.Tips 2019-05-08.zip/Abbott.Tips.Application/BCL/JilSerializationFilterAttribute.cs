﻿using Abbott.Tips.Framework.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Abbott.Tips.Application.BCL
{
    public class JilSerializationFilterAttribute : SerializationFilterAttribute
    {
    }
}
