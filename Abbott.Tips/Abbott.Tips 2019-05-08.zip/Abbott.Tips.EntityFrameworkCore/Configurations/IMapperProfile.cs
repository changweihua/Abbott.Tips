﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abbott.Tips.EntityFrameworkCore.Mappers
{
    /// <summary>
    /// AutoMapper Profile 接口，用于Autofac自动注入
    /// </summary>
    public interface IMapperProfile
    {

    }
}
