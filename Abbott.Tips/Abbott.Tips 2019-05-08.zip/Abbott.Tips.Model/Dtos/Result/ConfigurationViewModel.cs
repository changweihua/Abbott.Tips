﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Abbott.Tips.Model.Result
{
    #region 自定义

    #endregion

    
}
