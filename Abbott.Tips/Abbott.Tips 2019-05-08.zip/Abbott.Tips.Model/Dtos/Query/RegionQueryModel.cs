﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abbott.Tips.Model.Query
{
    public class RegionCreateModel
    {
        public string RegionName { get; set; }

        public int ParentId { get; set; }
    }
}
