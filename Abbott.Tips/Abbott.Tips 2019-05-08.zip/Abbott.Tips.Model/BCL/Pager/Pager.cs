﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abbott.Tips.Pager
{
    class Pager
    {
    }
}
